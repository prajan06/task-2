"""Sliding-window failure counter (in-memory, single process)."""
import threading
from collections import defaultdict, deque


class FailureLimiter:
    def __init__(self, max_failures: int, window: float, clock):
        self.max_failures = max_failures
        self.window = window
        self.clock = clock
        self._events = defaultdict(deque)
        self._lock = threading.Lock()

    def _prune(self, key, now):
        q = self._events[key]
        while q and now - q[0] >= self.window:
            q.popleft()
        if not q:
            self._events.pop(key, None)
        return q

    def retry_after(self, key) -> int:
        """Seconds until another attempt is allowed (0 = allowed now)."""
        with self._lock:
            now = self.clock()
            q = self._prune(key, now)
            if len(q) >= self.max_failures:
                return max(1, int(q[0] + self.window - now) + 1)
            return 0

    def record(self, key):
        with self._lock:
            self._events[key].append(self.clock())

    def reset(self, key):
        with self._lock:
            self._events.pop(key, None)
