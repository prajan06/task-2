"""Local development server. Use HTTPS (or a browser on localhost) because the
session cookie is marked Secure. Never run Flask's dev server in production."""
from auth_lab import create_app

if __name__ == "__main__":
    create_app().run(host="127.0.0.1", port=5000)
